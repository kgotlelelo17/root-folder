# mypackage
This library was created as an example of how tom publish your own Python package.

## building this package locally
`python setup.py sdict`

## installing this package from GitHub
`pip install git+https://github.com/kgotlelelo17/mypackage.git`

## updating this package from GitHub
`pip install --upgrade git+https://github.com/kgotlelelo17/mypackage.git`
